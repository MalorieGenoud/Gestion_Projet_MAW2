<?php
/********************************************************************
Product		: Flexicontact
Date		: 31 March 2016
Copyright	: Les Arbres Design 2010-2016
Contact		: http://www.lesarbresdesign.info
Licence		: GNU General Public License
*********************************************************************/
defined('_JEXEC') or die('Restricted Access');

class FlexicontactViewLog_List extends JViewLegacy
{
function display($tpl = null)
{
	Flexicontact_Utility::viewStart();
	JToolBarHelper::title(LAFC_COMPONENT_NAME.': '.JText::_('COM_FLEXICONTACT_LOG'), 'flexicontact.png');
	JToolBarHelper::deleteList('','delete_log');
	
// get the order states				

	$app = JFactory::getApplication();
	$filter_order = $app->getUserStateFromRequest(LAFC_COMPONENT.'.filter_order', 'filter_order', 'date_time');
	$filter_order_Dir = $app->getUserStateFromRequest(LAFC_COMPONENT.'.filter_order_Dir', 'filter_order_Dir', 'desc');
	$lists['order_Dir'] = $filter_order_Dir;
	$lists['order'] = $filter_order;

// get the current filters	
		
	$filter_date = $app->getUserStateFromRequest(LAFC_COMPONENT.'.filter_date','filter_date',LAFC_LOG_LAST_28_DAYS,'int');

// make the filter lists

	$date_filters = array(
		LAFC_LOG_ALL            => JText::_('COM_FLEXICONTACT_LOG_ALL'),
		LAFC_LOG_LAST_7_DAYS    => JText::_('COM_FLEXICONTACT_LOG_LAST_7_DAYS'),
		LAFC_LOG_LAST_28_DAYS   => JText::_('COM_FLEXICONTACT_LOG_LAST_28_DAYS'),
		LAFC_LOG_LAST_12_MONTHS => JText::_('COM_FLEXICONTACT_LOG_LAST_12_MONTHS')
		);
    
	$limit = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
	$list_limits = array('10' => '10', '20' => '20', '50' => '50', '100' => '100', '0' => JText::_('JALL'));
	$limit_list_html = Flexicontact_Utility::make_list('limit', $limit, $list_limits, 0, 'onchange="submitform();"');

	$lists['date_filters'] = Flexicontact_Utility::make_list('filter_date', $filter_date, $date_filters, 0, 'onchange="submitform( );"');					

	$numrows = count($this->log_list);

// Show the list

	?>
	<form action="index.php" method="post" name="adminForm" id="adminForm">
	<input type="hidden" name="option" value="<?php echo LAFC_COMPONENT ?>" />
	<input type="hidden" name="task" value="log_list" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="view" value="log_list" />
	<input type="hidden" name="filter_order" value="<?php echo $lists['order']; ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $lists['order_Dir']; ?>" />
    <?php
    echo "\n".'<div>&nbsp;<div style="float:left">'; 
	if ($this->logging)
		echo JText::_('COM_FLEXICONTACT_LOGGING').': '.JText::_('JYES');
    else
		echo JText::_('COM_FLEXICONTACT_LOGGING').': '.JText::_('JNO');
	echo '</div>'; 
	echo "\n".'<div style="float:right">'; 
    echo $lists['date_filters'];
    echo ' '.$limit_list_html;
    echo ' <button class="btn btn-primary" onclick="'."
            document.getElementById('filter_date').value='".LAFC_LOG_LAST_28_DAYS."';
            this.form.submit();".'">'.JText::_('JSEARCH_RESET').'</button>';
	echo '</div></div>'; 

    ?>
	<table class="table table-striped">
	<thead>
	<tr>
		<th style="width:20px; text-align:center;"><input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" /></th>
		<th style="white-space:nowrap;">
			<?php echo JHTML::_('grid.sort', 'COM_FLEXICONTACT_DATE_TIME', 'datetime', $lists['order_Dir'], $lists['order']); ?></th>
		<th style="white-space:nowrap;">
			<?php echo JHTML::_('grid.sort', 'COM_FLEXICONTACT_NAME', 'name', $lists['order_Dir'], $lists['order']); ?></th>
		<th style="white-space:nowrap;">
			<?php echo JHTML::_('grid.sort', 'COM_FLEXICONTACT_EMAIL', 'email', $lists['order_Dir'], $lists['order']); ?></th>
		<th style="white-space:nowrap;">
			<?php echo JHTML::_('grid.sort', 'COM_FLEXICONTACT_ADMIN_SUBJECT', 'subject', $lists['order_Dir'], $lists['order']); ?></th>
		<th style="white-space:nowrap;"><?php echo JText::_('COM_FLEXICONTACT_MESSAGE'); ?></th>
		<th style="white-space:nowrap;"><?php echo JText::_('COM_FLEXICONTACT_STATUS'); ?></th>
	</tr>
	</thead>

	<tfoot>
	<tr>
		<td colspan="15">
			<?php echo $this->pagination->getListFooter(); ?>
		</td>
	</tr>
	</tfoot>
	
	<tbody>
	<?php
	for ($i=0; $i < $numrows; $i++) 
		{
		$row = $this->log_list[$i];
		$link = LAFC_COMPONENT_LINK.'&task=log_detail&id='.$row->id;
		$checked = JHTML::_('grid.id', $i, $row->id);
		$date = JHTML::link($link, $row->datetime);
		$name = self::filter_text($row->name);
		$subject = self::filter_text($row->subject);
		$message = self::filter_text($row->short_message);
		$status_main = $this->_status($row->status_main);
		$status_copy = $this->_status($row->status_copy);

		echo '<tr>';
		echo '<td style="text-align:center;">'.$checked.'</td>';
		echo "<td>$date</td>
				<td>$name</td>
				<td>$row->email</td>
				<td>$subject</td>
				<td>$message</td>
				<td>$status_main $status_copy</td>
				</tr>\n";
		}
	echo '</tbody></table></form>';
	Flexicontact_Utility::viewEnd();
}

function filter_text($text)
{
	$clean_text = substr($text, 0, 60);
	$clean_text = str_replace('<br />', ' ', $clean_text);
	$clean_text = strip_tags($clean_text);
	$clean_text = str_replace(array('<','>'), '', $clean_text);
	return $clean_text;
}

function _status($status)
{
	if ($status == '0')		// '0' status means no mail was sent
		return ' ';
	if ($status == '1')		// '1' means email was sent ok
		return '<img src="'.LAFC_ADMIN_ASSETS_URL.'tick.png" alt="" />';
	return '<img src="'.LAFC_ADMIN_ASSETS_URL.'x.png" alt="" />';	    // anything else was an error
}

}